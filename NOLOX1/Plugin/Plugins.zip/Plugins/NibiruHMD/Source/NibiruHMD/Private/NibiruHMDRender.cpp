/* Copyright 2016 Nibiru Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#include "NibiruHMDPrivatePCH.h"
#include "NibiruHMD.h"
#include "ScreenRendering.h"

void FNibiruHMD::RenderTexture_RenderThread(class FRHICommandListImmediate& RHICmdList, class FRHITexture2D* BackBuffer, class FRHITexture2D* SrcTexture, FVector2D WindowSize) const
{
	check(IsInRenderingThread());

	const uint32 ViewportWidth = BackBuffer->GetSizeX();
	const uint32 ViewportHeight = BackBuffer->GetSizeY();
	const uint32 TextureWidth = SrcTexture->GetSizeX();
	const uint32 TextureHeight = SrcTexture->GetSizeY();

	int* texture_id = reinterpret_cast<int*>(SrcTexture->GetNativeResource());
	// RenderTexture_RenderThread() Viewport:(1920, 1080) Texture:(2048, 1024)
	//UE_LOG(LogHMD, Log, TEXT("RenderTexture_RenderThread() Viewport:(%d, %d) Texture:(%d, %d) BackBuffer=%p SrcTexture=%p [TextureId %d]"), ViewportWidth, ViewportHeight, TextureWidth, TextureHeight, BackBuffer, SrcTexture , *texture_id);

#if NIBIRUVRHMD_SUPPORTED_PLATFORMS
	// When using distortion method in NVR SDK
	if (useDTRMode)
	{
		// Use native nvr distortion without async reprojection
		// Note that this method is not enabled by default.
	 
		//When use aysnc reprojection, the framebuffer submit is handled in CustomPresent->FinishRendering
		return;
	}
	else
#endif // NIBIRUVRHMD_SUPPORTED_PLATFORMS
		// Just render directly to output
	{
		FGraphicsPipelineStateInitializer GraphicsPSOInit;
		GraphicsPSOInit.BlendState = TStaticBlendState<>::GetRHI();
		GraphicsPSOInit.RasterizerState = TStaticRasterizerState<>::GetRHI();
		GraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();

		FRHIRenderPassInfo RPInfo(BackBuffer, ERenderTargetActions::Load_Store);
		RHICmdList.BeginRenderPass(RPInfo, TEXT("NibiruVRHMD_RenderTexture"));
		{
			RHICmdList.ApplyCachedRenderTargets(GraphicsPSOInit);

			RHICmdList.SetViewport(0, 0, 0, ViewportWidth, ViewportHeight, 1.0f);

			const auto FeatureLevel = GMaxRHIFeatureLevel;
			auto ShaderMap = GetGlobalShaderMap(FeatureLevel);

			TShaderMapRef<FScreenVS> VertexShader(ShaderMap);
			TShaderMapRef<FScreenPS> PixelShader(ShaderMap);

			GraphicsPSOInit.BoundShaderState.VertexDeclarationRHI = GFilterVertexDeclaration.VertexDeclarationRHI;
			GraphicsPSOInit.BoundShaderState.VertexShaderRHI = GETSAFERHISHADER_VERTEX(*VertexShader);
			GraphicsPSOInit.BoundShaderState.PixelShaderRHI = GETSAFERHISHADER_PIXEL(*PixelShader);
			GraphicsPSOInit.PrimitiveType = PT_TriangleList;

			SetGraphicsPipelineState(RHICmdList, GraphicsPSOInit);

			PixelShader->SetParameters(RHICmdList, TStaticSamplerState<SF_Bilinear>::GetRHI(), SrcTexture);

			RendererModule->DrawRectangle(
				RHICmdList,
				0, 0,
				ViewportWidth, ViewportHeight,
				0.0f, 0.0f,
				1.0f, 1.0f,
				FIntPoint(ViewportWidth, ViewportHeight),
				FIntPoint(1, 1),
				*VertexShader,
				EDRF_Default);
		}
		RHICmdList.EndRenderPass();
	}
}
 
FXRRenderBridge* FNibiruHMD::GetActiveRenderBridge_GameThread(bool /* bUseSeparateRenderTarget */)
{
	check(IsInGameThread());
#if NIBIRUVRHMD_SUPPORTED_PLATFORMS
	if (useDTRMode)
	{
		return CustomPresent;
	}
#endif // NIBIRUVRHMD_SUPPORTED_PLATFORMS
	return nullptr;
}

bool FNibiruHMD::AllocateRenderTargetTexture(uint32 Index, uint32 SizeX, uint32 SizeY, uint8 Format, uint32 NumMips, uint32 InFlags, uint32 TargetableTextureFlags, FTexture2DRHIRef& OutTargetableTexture, FTexture2DRHIRef& OutShaderResourceTexture, uint32 NumSamples)
{
	//-AllocateRenderTargetTexture: Index[0] Size[2048,1024]
	// UE_LOG(LogHMD, Log, TEXT("AllocateRenderTargetTexture Begin ,  Index[%d] ,Size[%d,%d]"), Index, SizeX, SizeY);
	check(Index == 0);
	check(SizeX != 0 && SizeY != 0);
	check(IsInGameThread() && IsInRenderingThread()); // checking if rendering thread is suspended

#if NIBIRUVRHMD_SUPPORTED_PLATFORMS
	if (CustomPresent)
	{   
		const uint32 NumLayers = 1;
		bool Success = CustomPresent->AllocateRenderTargetTexture(Index, SizeX, SizeY, Format, NumLayers, NumMips, InFlags, TargetableTextureFlags);
		if (Success)
		{
			OutTargetableTexture = CustomPresent->TextureSet->GetTexture2D();
			OutShaderResourceTexture = CustomPresent->TextureSet->GetTexture2D();
			return true;
		}
		return false;
	}else {
		UE_LOG(LogHMD, Error, TEXT("AllocateRenderTargetTexture Failed , CustomPresent is NULL , Index[%d] ,Size[%d,%d]"), Index, SizeX, SizeY);
	}
#endif

	return false;
}


#if NIBIRUVRHMD_SUPPORTED_PLATFORMS
FNibiruVRHMDTexture2DSet::FNibiruVRHMDTexture2DSet(
	class FOpenGLDynamicRHI* InGLRHI,
	GLuint InResource,
	GLenum InTarget,
	GLenum InAttachment,
	uint32 InSizeX,
	uint32 InSizeY,
	uint32 InSizeZ,
	uint32 InNumMips,
	uint32 InNumSamples,
	uint32 InNumSamplesTileMem,
	uint32 InArraySize,
	EPixelFormat InFormat,
	bool bInCubemap,
	bool bInAllocatedStorage,
	uint32 InFlags,
	uint8* InTextureRange
)
	: FOpenGLTexture2D(
		InGLRHI,
		InResource,
		InTarget,
		InAttachment,
		InSizeX,
		InSizeY,
		InSizeZ,
		InNumMips,
		InNumSamples,
	    InNumSamplesTileMem,
		InArraySize,
		InFormat,
		bInCubemap,
		bInAllocatedStorage,
		InFlags,
		InTextureRange,
		FClearValueBinding::Black
	)
{
	 OpenGLTextureAllocated(this, InFlags);
	 FMemory::Memzero(Textures, sizeof(Textures));
     CurrentIndex = TextureCount = 0;
}

FNibiruVRHMDTexture2DSet::~FNibiruVRHMDTexture2DSet()
{
}

FNibiruVRHMDTexture2DSet *FNibiruVRHMDTexture2DSet::Self = nullptr;
void FNibiruVRHMDTexture2DSet::SwitchToNextElement()
{
	if (0==TextureCount)
    {
        CurrentIndex = 0;
    }
    else
    {
        CurrentIndex = (CurrentIndex + 1) % TextureCount;
    }
    InitWithCurrentElement();
}

void FNibiruVRHMDTexture2DSet::InitWithCurrentElement()
{
	 Resource = Textures[CurrentIndex];
}

FNibiruVRHMDTexture2DSet* FNibiruVRHMDTexture2DSet::CreateTexture2DSet(
	FOpenGLDynamicRHI* InGLRHI,
	uint32 DesiredSizeX, uint32 DesiredSizeY,
	uint32 InNumLayers, uint32 InNumSamples, uint32 InNumSamplesTileMem,
	EPixelFormat InFormat,
	uint32 InFlags)
{
	GLenum Target = (InNumSamples > 1) ? GL_TEXTURE_2D_MULTISAMPLE : GL_TEXTURE_2D;
	GLenum Attachment = GL_COLOR_ATTACHMENT0;
	bool bAllocatedStorage = false;
	uint32 NumMips = 1;
	uint8* TextureRange = nullptr;

	// Note that here we are passing a 0 as the texture resource id which means we are not creating the actually opengl texture resource here.
	FNibiruVRHMDTexture2DSet* NewTextureSet = new FNibiruVRHMDTexture2DSet(
		InGLRHI, 0, Target, Attachment, DesiredSizeX, DesiredSizeY, 0, NumMips, InNumSamples, InNumSamplesTileMem, InNumLayers, InFormat, false, bAllocatedStorage, InFlags, TextureRange);

	UE_LOG(LogHMD, Log, TEXT("Created FNibiruVRHMDTexture2DSet of size (%d, %d), NewTextureSet [%p]"), DesiredSizeX, DesiredSizeY, NewTextureSet);

	 //Allocate the RenderTarget Textures
    Self = NewTextureSet;
	uint32 textureWidth = DesiredSizeX; // 除2=single eye size * single eye size * 4  [720*720*4]
	uint32 textureHeight = DesiredSizeY;
	int useSmallTexture = NibiruImport::NibiruGetIntValue("small_texture_size",0);
	if (useSmallTexture == 1) {
		textureWidth = textureWidth / 2;
	}
    
    glGenTextures(TEXTURE_NUM, &Self->Textures[0]);
    int ids[TEXTURE_NUM];
    for (int i = 0; i < TEXTURE_NUM; i++)
    {
        glBindTexture(GL_TEXTURE_2D, Self->Textures[i]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, textureWidth, textureHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        ids[i] = (int) (Self->Textures[i]);
        UE_LOG(LogHMD, Log, TEXT("Created FNibiruVRHMDTexture2DSet of Texture Id (%d)"), (int) (Self->Textures[i]));
    }
    Self->TextureCount = TEXTURE_NUM;
    glBindTexture(GL_TEXTURE_2D, 0);

    // notify sdk that textures has gen success
    NibiruImport::NibiruCreateTextures(ids);
     
	return NewTextureSet;
}

FNibiruVRHMDCustomPresent::FNibiruVRHMDCustomPresent(FNibiruHMD* InHMD)
	: FXRRenderBridge()
	, CurrentFrame(nullptr)
	, HMD(InHMD)
	, CurrentFrameViewportList(nullptr)
{
	UE_LOG(LogHMD, Log, TEXT("chao::FNibiruVRHMDCustomPresent-init"));
	// set to identity
	CurrentFrameRenderHeadPose =	{ { { 1.0f, 0.0f, 0.0f, 0.0f },
									{ 0.0f, 1.0f, 0.0f, 0.0f },
									{ 0.0f, 0.0f, 1.0f, 0.0f },
									{ 0.0f, 0.0f, 0.0f, 1.0f } } };

}

FNibiruVRHMDCustomPresent::~FNibiruVRHMDCustomPresent()
{ 
	Shutdown();
}

void FNibiruVRHMDCustomPresent::Shutdown()
{ 
	UE_LOG(LogHMD, Log, TEXT("chao::FNibiruVRHMDCustomPresent-Shutdown"));
}


#if PLATFORM_ANDROID
namespace {
	int32 GetMobileMSAASampleSetting()
	{
		static const int32 MaxMSAASamplesSupported = FOpenGL::GetMaxMSAASamplesTileMem();
		static const auto CVarMobileMSAA = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("r.MobileMSAA"));
		static const int32 CVarMobileMSAAValue = CVarMobileMSAA->GetValueOnRenderThread();
		static const int32 MobileMSAAValue = FMath::Min(CVarMobileMSAAValue, MaxMSAASamplesSupported);
		if (MobileMSAAValue != CVarMobileMSAAValue)
		{
			UE_LOG(LogHMD, Warning, TEXT("r.MobileMSAA is set to %i but we are using %i due to hardware support limitations."), CVarMobileMSAAValue, MobileMSAAValue);
		}
		return MobileMSAAValue;
	}
}
#endif

bool FNibiruVRHMDCustomPresent::AllocateRenderTargetTexture(uint32 Index, uint32 SizeX, uint32 SizeY, uint8 Format, uint32 NumLayers, uint32 NumMips, uint32 InFlags, uint32 TargetableTextureFlags)
{
	//FNibiruVRHMDTexture2DSet of size (2048, 1024), NewTextureSet [0x8cf290e0]
	UE_LOG(LogHMD, Log, TEXT("chao::FNibiruVRHMDCustomPresent-AllocateRenderTargetTexture: Index[%d] Size[%d,%d]"),Index,SizeX,SizeY);

	FOpenGLDynamicRHI* GLRHI = static_cast<FOpenGLDynamicRHI*>(GDynamicRHI);

	if (TextureSet)
	{
		// Reassign the resource to 0 before destroy the texture since we are managing those resrouce in NVR.
		TextureSet->Resource = 0;
	}

    // InFlags=TexCreate_None, 
    // TargetableTextureFlags=TexCreate_RenderTargetable
    static int32 MobileMSAAValue = GetMobileMSAASampleSetting();
	TextureSet = FNibiruVRHMDTexture2DSet::CreateTexture2DSet(
		GLRHI,
		SizeX, SizeY, NumLayers,
		1, MobileMSAAValue,
		EPixelFormat(Format),
		TexCreate_RenderTargetable
	);

	if (!TextureSet.IsValid())
	{
		return false;
	}

	RenderTargetSize = nvr_sizei{ static_cast<int32_t>(SizeX), static_cast<int32_t>(SizeY) };
	bNeedResizeNVRRenderTarget = true;

	return true;
}

void FNibiruVRHMDCustomPresent::BeginRendering(uint32 frameNum, const nvr_mat4f& RenderingHeadPose)
{
    NibiruImport::NibiruSetIntValue(NIB_KEY_BEGIN_FRAME_NUM,(int)frameNum);
    // Cache the render headpose we use for this frame
    CurrentFrameRenderHeadPose = RenderingHeadPose;
}

void FNibiruVRHMDCustomPresent::FinishRendering()
{
	check(IsInRenderingThread());

    if (HMD && TextureSet) {
        GLuint TexId = TextureSet->GetCurrentTexture();
        //UE_LOG(LogHMD, Log, TEXT("chao::FinishRendering TextureSet.%d"), TexId);
 
        // TEST
        // API returns framebuffer resource, but we need the texture resource for the pipeline
		//check(PLATFORM_USES_ES2); // Some craziness will only work on OpenGL platforms.
		//GLint TextureId = 0;
		//glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME, &TextureId);
		//override the texture set in custom present to the texture id we just bind so that unreal could render to it.
		//UE_LOG(LogHMD, Log, TEXT("chao::FinishRendering Currently FBO .%d"), TextureId);
        // TEST

        // 把cache的headpose传递给SDK
        NibiruImport::NibiruSetTexture((void *)(TexId), HMD->GetViewNum());
 
        TextureSet->SwitchToNextElement();

		HMD->bBeginFrame = false;
    }else if(!TextureSet) {
        UE_LOG(LogHMD, Log, TEXT("chao::FinishRendering TextureSet is NULL"));
    }
}

bool FNibiruVRHMDCustomPresent::NeedsNativePresent()
{
	return false;
}

bool FNibiruVRHMDCustomPresent::Present(int32& InOutSyncInterval)
{
	FinishRendering();
	// Note: true causes normal swapbuffers(), false prevents normal swapbuffers()
 
    if(HMD)
    {
    	HMD->UpdateNibiruHeadPose();
    }
	return false;
 
}

void FNibiruVRHMDCustomPresent::OnBackBufferResize()
{
	UE_LOG(LogHMD, Log, TEXT("chao::OnBackBufferResize"));
}

void FNibiruVRHMDCustomPresent::EnterVRMode_RenderThread() 
{
	check(IsInRenderingThread());
	nvrModeParms parms; 
	parms.Display = (size_t)AndroidEGL::GetInstance()->GetDisplay();
	parms.WindowSurface = (size_t)AndroidEGL::GetInstance()->GetNativeWindow();
	parms.ShareContext = (size_t)AndroidEGL::GetInstance()->GetRenderingContext()->eglContext;
	NibiruImport::NibiruEnterVRMode(&parms);
	UE_LOG(LogHMD, Log, TEXT("EnterVRMode_RenderThread"));
}

void FNibiruVRHMDCustomPresent::LeaveVRMode_RenderThread() 
{
	check(IsInRenderingThread());
	NibiruImport::NibiruLeaveVRMode();
	UE_LOG(LogHMD, Log, TEXT("LeaveVRMode_RenderThread"));
}

#endif // NIBIRUVRHMD_SUPPORTED_PLATFORMS