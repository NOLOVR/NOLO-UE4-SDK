//=============================================================================
//
//                  Copyright (c) 2018 QUALCOMM Technologies Inc.
//                              All Rights Reserved.
//
//==============================================================================

#pragma once
#include "HuaweiVRCustomPresent.h"
#include "CoreMinimal.h"
#include "IHeadMountedDisplay.h"
#include "IHuaweiVRSDKPlugin.h"
#include "Runtime/Engine/Public/ScreenRendering.h"